# figures

Folder for all figures.

You can create further sub-folders if that makes sense.
